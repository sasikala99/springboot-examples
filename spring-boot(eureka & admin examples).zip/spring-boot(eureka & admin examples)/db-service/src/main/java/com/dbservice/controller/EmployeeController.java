package com.dbservice.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dbservice.model.Employee;
import com.dbservice.repository.EmployeeRepository;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@PostMapping(value="/save")
	public Map<String,Object> saveemployee(@RequestBody Employee employee){
		Map<String,Object> resultmap = new HashMap<String,Object>();
		employeeRepository.save(employee);
		resultmap.put("employeedata", employeeRepository.findAll());
		return resultmap;
	}
	
	@GetMapping(value="/employees")
	public Map<String,Object> getemployee(){
		Map<String,Object> resultmap = new HashMap<String,Object>();
		resultmap.put("employeesdata", employeeRepository.findAll());
		return resultmap;
	}
	
	@GetMapping(value="/employee/{eid}")
	public Map<String,Object> getemployeebyid(@PathVariable("eid") Integer eid){
		Map<String,Object> resultmap = new HashMap<String,Object>();
		resultmap.put("employeedata", employeeRepository.findOne(eid));
		return resultmap;
	}
}
