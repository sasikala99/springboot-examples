package com.dbconsumingservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ConsumingController {

	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping(value="/consumeemployee")
	public String getemployeedata(){
		String str = restTemplate.getForObject("http://db-service/employees", String.class);
		return str;
	}
}
